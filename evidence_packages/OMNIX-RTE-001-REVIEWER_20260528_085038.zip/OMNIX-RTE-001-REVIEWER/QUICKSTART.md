# QUICKSTART.md — First-Time Reviewer

This is the fastest path from download to verified result.

---

## Step 0 — Install the PQC verification library (one-time)

```
pip install pqc
```

This installs the Dilithium-3 (ML-DSA-65) verification library.
It takes approximately 5 seconds and has no other dependencies.

Without this step, the 26 PQC signature checks are SKIPPED rather than FAILED.
The 75 structural and hash integrity checks run regardless.

---

## Step 1 — Confirm Python version

```
python --version
```

Any version >= 3.9 works.

---

## Step 2 — Run full verification

```
python verify.py
```

This runs 111 checks across both execution paths (dangerous and admissible).
It takes approximately 3-5 seconds.

With `pqc` installed you should see:

```
  TOTAL CHECKS : 111
  PASSED        : 111
  FAILED        : 0
  VERDICT: ALL VERIFICATIONS PASS — package integrity confirmed
```

If you see this, the package has not been altered, all PQC signatures are
cryptographically valid, and the structural invariants hold.

---

## Step 3 — Verify the HALT (dangerous path)

```
python verify.py --verify-halt
```

This proves that the autonomous agent was stopped before any execution occurred.

Key checks:
- `execution_occurred = False`
- `settlement_released = False`
- OSG verdict = `REJECTED`
- Refusal type = `HARD_REFUSAL`
- CTCHC sealed in HALTED state (BEV-INV-013)

Expected: `25 / 25 PASS`

---

## Step 4 — Verify the settlement (admissible path)

```
python verify.py --verify-settlement
```

This proves that the same agent, under recertified authority, executed the
transfer and that the execution is forensically sealed.

Key checks:
- TAR status = `ADMITTED`
- PoGC `POGC-F1DC0218E5204875` = `MANDATE-BOUND`
- Settlement amount = USD 50,000,000
- OSG verdict = `APPROVED`

Expected: `33 / 33 PASS`

---

## Step 5 — Inspect the raw evidence

The complete evidence package is in `evidence/OMNIX-RTE-001_*.json`.
It is a self-contained JSON file with all artifacts for both paths.

```python
import json
pkg = json.load(open("evidence/OMNIX-RTE-001_20260528_071811.json"))

# Dangerous path summary
print(json.dumps(pkg["paths"]["path_dangerous"]["summary"], indent=2))

# Admissible path summary
print(json.dumps(pkg["paths"]["path_admissible"]["summary"], indent=2))

# Public key used to verify all 111 signatures
print(pkg["pqc"]["algorithm"])
print(pkg["pqc"]["public_key_b64"][:80], "...")
```

---

## Step 6 — Read the institutional document

Open `evidence/OMNIX-RTE-001_*.pdf` for a 15-page forensic narrative
covering all artifacts, both paths, and the verification report.

---

## What this package demonstrates

| Property | Status |
|---|---|
| Autonomous agent halted before execution | Proven cryptographically |
| Halt is offline-verifiable without OMNIX | Confirmed (111/111 PASS) |
| Admissible execution forensically sealed | Proven cryptographically |
| PoGC issued for admissible settlement | POGC-F1DC0218E5204875 |
| PQC algorithm | ML-DSA-65 (Dilithium-3, FIPS 204) |
| External infrastructure required | None |
| Network access required | None |
| OMNIX platform access required | None |
| Python dependency | `pip install pqc` (PQC signatures only) |

---

## Questions or challenges

If you find a check that fails, or a signature that does not verify,
that is a finding worth reporting. The package is designed to be challenged.

Contact: OMNIX QUANTUM LTD — Harold Nunes
Standard: RFC-ATF-1 through RFC-ATF-6 · ADR-201
